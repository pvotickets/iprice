package operation;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class UIOperation {

	WebDriver driver;

	public UIOperation(WebDriver driver) {
		this.driver = driver;
	}

	public void TypeInField(String id, String value) {
		String val = value;
		WebElement element = driver.findElement(By.id(id));
		element.clear();

		for (int i = 0; i < val.length(); i++) {
			char c = val.charAt(i);
			String s = new StringBuilder().append(c).toString();
			element.sendKeys(s);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			element.sendKeys(Keys.SPACE);
			element.sendKeys(Keys.BACK_SPACE);
		}
	}

	public void perform(Properties p, String operation, String objectName, String objectType, String value)
			throws Exception {
		System.out.println("");
		switch (operation.toUpperCase()) {
		case "CLICK":
			// Perform click
			driver.findElement(this.getObject(p, objectName, objectType)).click();
			break;
		case "SETTEXT":
			// Set text on control
			driver.findElement(this.getObject(p, objectName, objectType)).sendKeys(value);
			break;

		case "GOTOURL":
			// Get url of application
			driver.get(p.getProperty(value));
			driver.manage().window().maximize();
			Thread.sleep(5000);
			break;

		case "GETTEXT":
			// Get text of an element
			driver.findElement(this.getObject(p, objectName, objectType)).getText();
			break;

		case "VERIFYTEXT":
			// Get text of an element
			String bodyText = driver.findElement(this.getObject(p, objectName, objectType)).getText();
			Assert.assertTrue("Text not matching!", bodyText.contains(value));
			break;

		case "SELECTDROPDOWN":

			WebElement dropdown = driver.findElement(this.getObject(p, objectName, objectType));
			dropdown.click();
			List<WebElement> locoptions = dropdown.findElements(By.id("nearby-location-dropdown"));
			locoptions.get(2).click();

			break;

		case "WAIT":
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			break;

		case "FINDOBJECTS":
			List<WebElement> list = driver.findElements(By.xpath(
					"//div[@class='bg']//div[@class='kF']//div[@class='i-amphtml-carousel-content']//div[@class='i-amphtml-carousel-scroll']//a"));
			System.out.println(list.size());

			for (WebElement we : list) {
				System.out.println(we.getAttribute("href"));
				String link = we.getAttribute("href");
				System.out.println(we.getTagName() + "=" + link + " , " + we.getText());
			}

		case "FINDPRODUCTS":

			List<WebElement> productList = driver.findElements(By.xpath(
					"//div[@class='C I l eU']//div[@class='i-amphtml-carousel-content']//div[@class='i-amphtml-carousel-scroll']//a"));
			System.out.println(productList.size());

			for (WebElement we : productList) {
				System.out.println(we.getAttribute("href"));
				String link = we.getAttribute("href");
				System.out.println(we.getTagName() + "=" + link + " , " + we.getText());

			}

			try {
				productList.contains("data-vars-cgt");
				System.out.println("data-vars-cgt is present");
			} catch (NoSuchElementException e) {
				System.out.println("Article element is not present");
			}
			
		case "VERIFYLINKENBALED":
			List<WebElement> linkList = driver.findElements(By.xpath(
					"//div[@class='lH']//div[ @data-uat='top-stores']//section//div"));
			for (WebElement we : linkList)
			{
			  if (we.getAttribute("href").contains("iprice.my"));
			  {
				  System.out.println("=> The href is present...");
			  }
			}

		default:
			break;
		}
	}

	/**
	 * Find element BY using object type and value
	 * 
	 * @param p
	 * @param objectName
	 * @param objectType
	 * @return
	 * @throws Exception
	 */
	private By getObject(Properties p, String objectName, String objectType) throws Exception {
		// Find by xpath
		if (objectType.equalsIgnoreCase("XPATH")) {

			return By.xpath(p.getProperty(objectName));
		}
		// find by class
		else if (objectType.equalsIgnoreCase("CLASSNAME")) {

			return By.className(p.getProperty(objectName));

		}
		// find by name
		else if (objectType.equalsIgnoreCase("NAME")) {

			return By.name(p.getProperty(objectName));

		}

		// find by id
		else if (objectType.equalsIgnoreCase("ID")) {

			return By.id(p.getProperty(objectName));

		}

		// Find by css
		else if (objectType.equalsIgnoreCase("CSS")) {

			return By.cssSelector(p.getProperty(objectName));

		}
		// find by link
		else if (objectType.equalsIgnoreCase("LINK")) {

			return By.linkText(p.getProperty(objectName));

		}
		// find by partial link
		else if (objectType.equalsIgnoreCase("PARTIALLINK")) {

			return By.partialLinkText(p.getProperty(objectName));

		} else {
			throw new Exception("Wrong object type");
		}
	}
}
